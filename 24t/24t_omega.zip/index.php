<?php
header("location:map4.php");
?>